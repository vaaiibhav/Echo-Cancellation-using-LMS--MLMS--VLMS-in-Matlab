function FiltOutPlay
% Author: F. W. Isen
% Copyright 2009 by Morgan & Claypool
global FiltOut

soundsc(FiltOut, 1024)