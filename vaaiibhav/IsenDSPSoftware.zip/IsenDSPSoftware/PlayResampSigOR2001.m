function PlayResampSigOR2001
% Author: F. W. Isen
% Copyright 2009 by Morgan & Claypool
global ResampledSig2001 OrigSR2001

soundsc(ResampledSig2001, OrigSR2001)