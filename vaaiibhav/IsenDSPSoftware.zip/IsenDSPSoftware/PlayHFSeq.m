function PlayHFSeq
global origsig thisSR
% Author: F. W. Isen
% Copyright 2009 by Morgan & Claypool
soundsc(origsig,thisSR); % play out the original sequence