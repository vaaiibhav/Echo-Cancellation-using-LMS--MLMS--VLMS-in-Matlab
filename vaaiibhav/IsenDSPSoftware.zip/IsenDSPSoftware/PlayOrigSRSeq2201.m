function PlayOrigSRSeq2201
% Author: F. W. Isen
% Copyright 2009 by Morgan & Claypool
global  TheOrigSig2201 OrigSR2201

soundsc(TheOrigSig2201, OrigSR2201)