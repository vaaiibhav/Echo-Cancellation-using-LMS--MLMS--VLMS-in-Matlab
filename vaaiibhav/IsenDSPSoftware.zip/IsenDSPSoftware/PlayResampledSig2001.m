function PlayResampledSig2001
% Author: F. W. Isen
% Copyright 2009 by Morgan & Claypool
global ResampledSig2001 FinalSR2001

soundsc(ResampledSig2001, FinalSR2001)