function PlayOrigSRSeq2001
% Author: F. W. Isen
% Copyright 2009 by Morgan & Claypool
global  TheOrigSig2001 OrigSR2001

soundsc(TheOrigSig2001, OrigSR2001)