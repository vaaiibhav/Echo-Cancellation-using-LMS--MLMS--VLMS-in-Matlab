function PlayResampledSig2201
% Author: F. W. Isen
% Copyright 2009 by Morgan & Claypool
global ResampledSig2201 FinalSR2201

soundsc(ResampledSig2201, FinalSR2201)