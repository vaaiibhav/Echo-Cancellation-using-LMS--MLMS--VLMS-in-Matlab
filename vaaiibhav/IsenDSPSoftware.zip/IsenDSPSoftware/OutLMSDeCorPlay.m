function OutLMSDeCorPlay
% Author: F. W. Isen
% Copyright 2009 by Morgan & Claypool
global Err 
soundsc(Err, 1024)